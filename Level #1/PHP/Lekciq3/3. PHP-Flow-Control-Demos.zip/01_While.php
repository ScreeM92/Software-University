<!DOCTYPE html>
<html>

<head lang="en">
    <meta charset="UTF-8">
    <title></title>
</head>

<body>
<?php
$counter = 10;
while ($counter > 0){
    echo $counter . '</br>';
    $counter--;
}
?>
</body>

</html>
