<?php
require "header.php";
?>
<h1>Software University</h1>
<?php
include "footer.php";
?>