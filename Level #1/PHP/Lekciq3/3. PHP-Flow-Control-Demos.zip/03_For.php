<!DOCTYPE html>
<html>

<head lang="en">
    <meta charset="UTF-8">
    <title></title>
</head>

<body>
<?php
for ($x=0; $x<=10; $x++) {
    echo "The number is: $x <br>\n";
}
?>
</body>

</html>

