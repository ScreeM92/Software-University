<!DOCTYPE html>
<html>

<head lang="en">
    <meta charset="UTF-8">
    <title></title>
</head>

<body>
<?php
//exit() example
echo "I am going to exit";
exit(2);

//die() always exists with code 0
die("I am going to die");
?>
</body>

</html>