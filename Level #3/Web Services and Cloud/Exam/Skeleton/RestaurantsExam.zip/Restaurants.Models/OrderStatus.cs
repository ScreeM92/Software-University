﻿public enum OrderStatus
{
    Pending,
    Delivered
}