﻿using System;

namespace SoftUni.Data
{
    public enum Specialty
    {
        ComputerScience,
        SoftwareEngineering,
        InformationSystems
    }
}
