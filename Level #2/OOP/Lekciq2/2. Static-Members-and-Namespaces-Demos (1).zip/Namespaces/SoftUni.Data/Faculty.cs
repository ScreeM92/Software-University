﻿using System;

namespace SoftUni.Data
{
    public struct Faculty
    {
        public string Name { get; set; }
    }
}
