﻿using System;

namespace SoftUni
{
    public class AdministrationSystem
    {
        static void Main()
        {
            // ...
        }
    }
}
